package 설계;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DataManager {
    private static final String DATA_DIR = "data/";
    private static final String USERS_FILE = DATA_DIR + "users.txt";
    private static final String DEADLINES_FILE = DATA_DIR + "deadlines.txt";
    private static final String TODOS_FILE = DATA_DIR + "todos.txt";
    private static final String SESSIONS_FILE = DATA_DIR + "sessions.txt";

    public DataManager() {
        new File(DATA_DIR).mkdirs();
    }

    // User
    public void saveUser(User user) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(USERS_FILE, true))) {
            pw.println(user.getUserId() + "," + user.getPassword() + "," + user.getName());
        }
    }

    public User loadUser(String userId, String password) throws IOException {
        File f = new File(USERS_FILE);
        if (!f.exists()) return null;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3 && parts[0].equals(userId) && parts[1].equals(password)) {
                    return new User(parts[0], parts[1], parts[2]);
                }
            }
        }
        return null;
    }

    public boolean userExists(String userId) throws IOException {
        File f = new File(USERS_FILE);
        if (!f.exists()) return false;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 1 && parts[0].equals(userId)) return true;
            }
        }
        return false;
    }

    // Deadline
    public void saveDeadline(DeadlineItem item) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(DEADLINES_FILE, true))) {
            pw.println(item.getItemId() + "," + item.getUserId() + "," + item.getTitle() + "," + item.getSubject() + "," + item.getDueDate());
        }
    }

    public List<DeadlineItem> loadDeadlines(String userId) throws IOException {
        List<DeadlineItem> list = new ArrayList<>();
        File f = new File(DEADLINES_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5 && parts[1].equals(userId)) {
                    list.add(new DeadlineItem(parts[0], parts[1], parts[2], parts[3], LocalDate.parse(parts[4])));
                }
            }
        }
        return list;
    }

    // Todo
    public void saveTodo(TodoItem item) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(TODOS_FILE, true))) {
            pw.println(item.getTodoId() + "," + item.getUserId() + "," + item.getSubject() + "," + item.getContent() + "," + item.isCompleted());
        }
    }

    public List<TodoItem> loadTodos(String userId) throws IOException {
        List<TodoItem> list = new ArrayList<>();
        File f = new File(TODOS_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5 && parts[1].equals(userId)) {
                    TodoItem t = new TodoItem(parts[0], parts[1], parts[2], parts[3]);
                    t.setCompleted(Boolean.parseBoolean(parts[4]));
                    list.add(t);
                }
            }
        }
        return list;
    }

    public void saveAllTodos(List<TodoItem> todos) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(TODOS_FILE, false))) {
            for (TodoItem t : todos) {
                pw.println(t.getTodoId() + "," + t.getUserId() + "," + t.getSubject() + "," + t.getContent() + "," + t.isCompleted());
            }
        }
    }

    // Session
    public void saveSession(StudySession session) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(SESSIONS_FILE, true))) {
            pw.println(session.getSessionId() + "," + session.getUserId() + "," + session.getSubject() + "," + session.getStartTime() + "," + session.getEndTime() + "," + session.getDurationSeconds());
        }
    }
}