package 설계;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.util.UUID;

public class TimerPanel extends JPanel {
    private User user;
    private DataManager dm;
    private JLabel timeLabel;
    private JTextField subjectField;
    private JButton startBtn, stopBtn;
    private Timer timer;
    private LocalDateTime startTime;
    private int elapsed;

    public TimerPanel(User user, DataManager dm) {
        this.user = user;
        this.dm = dm;
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel title = new JLabel("공부 타이머", SwingConstants.CENTER);
        title.setFont(new Font("맑은 고딕", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("과목:"), gbc);
        gbc.gridx = 1;
        subjectField = new JTextField(15);
        add(subjectField, gbc);

        timeLabel = new JLabel("00:00:00", SwingConstants.CENTER);
        timeLabel.setFont(new Font("맑은 고딕", Font.BOLD, 36));
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        add(timeLabel, gbc);

        startBtn = new JButton("시작");
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 1;
        add(startBtn, gbc);

        stopBtn = new JButton("종료");
        stopBtn.setEnabled(false);
        gbc.gridx = 1;
        add(stopBtn, gbc);

        startBtn.addActionListener(e -> startTimer());
        stopBtn.addActionListener(e -> stopTimer());
    }

    private void startTimer() {
        String subject = subjectField.getText().trim();
        if (subject.isEmpty()) {
            JOptionPane.showMessageDialog(this, "과목을 입력해주세요.");
            return;
        }
        startTime = LocalDateTime.now();
        elapsed = 0;
        startBtn.setEnabled(false);
        stopBtn.setEnabled(true);
        subjectField.setEnabled(false);

        timer = new Timer(1000, e -> {
            elapsed++;
            int h = elapsed / 3600;
            int m = (elapsed % 3600) / 60;
            int s = elapsed % 60;
            timeLabel.setText(String.format("%02d:%02d:%02d", h, m, s));
        });
        timer.start();
    }

    private void stopTimer() {
        timer.stop();
        LocalDateTime endTime = LocalDateTime.now();
        startBtn.setEnabled(true);
        stopBtn.setEnabled(false);
        subjectField.setEnabled(true);

        try {
            StudySession session = new StudySession(
                UUID.randomUUID().toString(),
                user.getUserId(),
                subjectField.getText().trim(),
                startTime,
                endTime,
                elapsed
            );
            dm.saveSession(session);
            JOptionPane.showMessageDialog(this, "공부 완료! " + elapsed/60 + "분 " + elapsed%60 + "초");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "저장 오류: " + ex.getMessage());
        }

        elapsed = 0;
        timeLabel.setText("00:00:00");
    }
}