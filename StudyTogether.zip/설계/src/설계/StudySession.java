package 설계;

import java.time.LocalDateTime;

public class StudySession {
    private String sessionId;
    private String userId;
    private String subject;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private long durationSeconds;

    public StudySession(String sessionId, String userId, String subject, LocalDateTime startTime, LocalDateTime endTime, long durationSeconds) {
        this.sessionId = sessionId;
        this.userId = userId;
        this.subject = subject;
        this.startTime = startTime;
        this.endTime = endTime;
        this.durationSeconds = durationSeconds;
    }

    public String getSessionId() { return sessionId; }
    public String getUserId() { return userId; }
    public String getSubject() { return subject; }
    public LocalDateTime getStartTime() { return startTime; }
    public LocalDateTime getEndTime() { return endTime; }
    public long getDurationSeconds() { return durationSeconds; }
}