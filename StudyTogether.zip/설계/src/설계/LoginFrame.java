package 설계;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private DataManager dm;
    private JTextField idField;
    private JPasswordField pwField;

    public LoginFrame() {
        dm = new DataManager();
        setTitle("StudyTogether - 로그인");
        setSize(350, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("StudyTogether", SwingConstants.CENTER);
        title.setFont(new Font("맑은 고딕", Font.BOLD, 20));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("아이디:"), gbc);
        gbc.gridx = 1;
        idField = new JTextField(15);
        add(idField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        add(new JLabel("비밀번호:"), gbc);
        gbc.gridx = 1;
        pwField = new JPasswordField(15);
        add(pwField, gbc);

        JButton loginBtn = new JButton("로그인");
        gbc.gridx = 0; gbc.gridy = 3;
        add(loginBtn, gbc);

        JButton registerBtn = new JButton("회원가입");
        gbc.gridx = 1;
        add(registerBtn, gbc);

        loginBtn.addActionListener(e -> login());
        registerBtn.addActionListener(e -> register());

        setVisible(true);
    }

    private void login() {
        String id = idField.getText().trim();
        String pw = new String(pwField.getPassword()).trim();
        if (id.isEmpty() || pw.isEmpty()) {
            JOptionPane.showMessageDialog(this, "아이디와 비밀번호를 입력해주세요.");
            return;
        }
        try {
            User user = dm.loadUser(id, pw);
            if (user != null) {
                dispose();
                new MainFrame(user, dm);
            } else {
                JOptionPane.showMessageDialog(this, "아이디 또는 비밀번호가 틀렸습니다.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "오류: " + ex.getMessage());
        }
    }

    private void register() {
        String id = idField.getText().trim();
        String pw = new String(pwField.getPassword()).trim();
        if (id.isEmpty() || pw.isEmpty()) {
            JOptionPane.showMessageDialog(this, "아이디와 비밀번호를 입력해주세요.");
            return;
        }
        try {
            if (dm.userExists(id)) {
                JOptionPane.showMessageDialog(this, "이미 존재하는 아이디입니다.");
                return;
            }
            String name = JOptionPane.showInputDialog(this, "이름을 입력해주세요:");
            if (name == null || name.trim().isEmpty()) return;
            dm.saveUser(new User(id, pw, name.trim()));
            JOptionPane.showMessageDialog(this, "회원가입 완료! 로그인해주세요.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "오류: " + ex.getMessage());
        }
    }
}
