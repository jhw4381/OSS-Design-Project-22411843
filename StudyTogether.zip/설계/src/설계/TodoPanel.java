package 설계;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.UUID;

public class TodoPanel extends JPanel {
    private User user;
    private DataManager dm;
    private DefaultTableModel tableModel;
    private JTable table;
    private List<TodoItem> todos;

    public TodoPanel(User user, DataManager dm) {
        this.user = user;
        this.dm = dm;
        setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(new String[]{"완료", "과목", "내용"}, 0) {
            public boolean isCellEditable(int r, int c) { return c == 0; }
            public Class<?> getColumnClass(int c) { return c == 0 ? Boolean.class : String.class; }
        };
        table = new JTable(tableModel);
        table.getColumnModel().getColumn(0).setMaxWidth(50);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel();
        JButton addBtn = new JButton("추가");
        JButton deleteBtn = new JButton("삭제");
        JButton saveBtn = new JButton("저장");
        bottom.add(addBtn);
        bottom.add(deleteBtn);
        bottom.add(saveBtn);
        add(bottom, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addTodo());
        deleteBtn.addActionListener(e -> deleteTodo());
        saveBtn.addActionListener(e -> saveTodos());

        loadTodos();
    }

    private void loadTodos() {
        tableModel.setRowCount(0);
        try {
            todos = dm.loadTodos(user.getUserId());
            for (TodoItem t : todos) {
                tableModel.addRow(new Object[]{t.isCompleted(), t.getSubject(), t.getContent()});
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "불러오기 오류: " + ex.getMessage());
        }
    }

    private void addTodo() {
        JTextField subjectField = new JTextField();
        JTextField contentField = new JTextField();

        Object[] msg = {"과목:", subjectField, "내용:", contentField};
        int result = JOptionPane.showConfirmDialog(this, msg, "Todo 추가", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String subject = subjectField.getText().trim();
                String content = contentField.getText().trim();
                TodoItem t = new TodoItem(UUID.randomUUID().toString(), user.getUserId(), subject, content);
                dm.saveTodo(t);
                loadTodos();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "오류: " + ex.getMessage());
            }
        }
    }

    private void deleteTodo() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "삭제할 항목을 선택해주세요.");
            return;
        }
        todos.remove(row);
        try {
            dm.saveAllTodos(todos);
            loadTodos();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "오류: " + ex.getMessage());
        }
    }

    private void saveTodos() {
        for (int i = 0; i < todos.size(); i++) {
            todos.get(i).setCompleted((Boolean) tableModel.getValueAt(i, 0));
        }
        try {
            dm.saveAllTodos(todos);
            JOptionPane.showMessageDialog(this, "저장 완료!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "오류: " + ex.getMessage());
        }
    }
}