package 설계;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    public MainFrame(User user, DataManager dm) {
        setTitle("StudyTogether - " + user.getName());
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("D-day", new DeadlinePanel(user, dm));
        tabs.addTab("타이머", new TimerPanel(user, dm));
        tabs.addTab("Todo", new TodoPanel(user, dm));

        add(tabs);
        setVisible(true);
    }
}
