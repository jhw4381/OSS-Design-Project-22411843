package 설계;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public class DeadlinePanel extends JPanel {
    private User user;
    private DataManager dm;
    private DefaultTableModel tableModel;
    private JTable table;

    public DeadlinePanel(User user, DataManager dm) {
        this.user = user;
        this.dm = dm;
        setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(new String[]{"제목", "과목", "마감일", "남은 일수"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel();
        JButton addBtn = new JButton("D-day 추가");
        JButton deleteBtn = new JButton("삭제");
        bottom.add(addBtn);
        bottom.add(deleteBtn);
        add(bottom, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addDeadline());
        deleteBtn.addActionListener(e -> deleteDeadline());

        loadDeadlines();
    }

    private void loadDeadlines() {
        tableModel.setRowCount(0);
        try {
            List<DeadlineItem> list = dm.loadDeadlines(user.getUserId());
            for (DeadlineItem item : list) {
                long days = item.getDaysLeft();
                String daysStr = days < 0 ? "만료" : "D-" + days;
                tableModel.addRow(new Object[]{item.getTitle(), item.getSubject(), item.getDueDate(), daysStr});
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "불러오기 오류: " + ex.getMessage());
        }
    }

    private void addDeadline() {
        JTextField titleField = new JTextField();
        JTextField subjectField = new JTextField();
        JTextField dateField = new JTextField("2026-06-30");

        Object[] msg = {
            "제목:", titleField,
            "과목:", subjectField,
            "마감일 (yyyy-MM-dd):", dateField
        };

        int result = JOptionPane.showConfirmDialog(this, msg, "D-day 추가", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String title = titleField.getText().trim();
                String subject = subjectField.getText().trim();
                LocalDate date = LocalDate.parse(dateField.getText().trim());
                DeadlineItem item = new DeadlineItem(UUID.randomUUID().toString(), user.getUserId(), title, subject, date);
                dm.saveDeadline(item);
                loadDeadlines();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "오류: " + ex.getMessage());
            }
        }
    }

    private void deleteDeadline() {
        JOptionPane.showMessageDialog(this, "삭제 기능은 추후 지원됩니다.");
    }
}