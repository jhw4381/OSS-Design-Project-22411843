package 설계;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class DeadlineItem {
    private String itemId;
    private String userId;
    private String title;
    private String subject;
    private LocalDate dueDate;

    public DeadlineItem(String itemId, String userId, String title, String subject, LocalDate dueDate) {
        this.itemId = itemId;
        this.userId = userId;
        this.title = title;
        this.subject = subject;
        this.dueDate = dueDate;
    }

    public String getItemId() { return itemId; }
    public String getUserId() { return userId; }
    public String getTitle() { return title; }
    public String getSubject() { return subject; }
    public LocalDate getDueDate() { return dueDate; }

    public long getDaysLeft() {
        return ChronoUnit.DAYS.between(LocalDate.now(), dueDate);
    }

    public boolean isExpired() {
        return getDaysLeft() < 0;
    }
}