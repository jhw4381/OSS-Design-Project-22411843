package 설계;

public class TodoItem {
    private String todoId;
    private String userId;
    private String subject;
    private String content;
    private boolean isCompleted;

    public TodoItem(String todoId, String userId, String subject, String content) {
        this.todoId = todoId;
        this.userId = userId;
        this.subject = subject;
        this.content = content;
        this.isCompleted = false;
    }

    public String getTodoId() { return todoId; }
    public String getUserId() { return userId; }
    public String getSubject() { return subject; }
    public String getContent() { return content; }
    public boolean isCompleted() { return isCompleted; }
    public void setCompleted(boolean completed) { this.isCompleted = completed; }
}
